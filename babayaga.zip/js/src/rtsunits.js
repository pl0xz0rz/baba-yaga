define({
  normalzombie:{
    id: 1,
    str: 1,
    inventory: {},
    hp: 10,
    mana: 0,
    cost: 80
  },
  peasant:{
    id: 2,
    str: 2,
    inventory: {},
    hp: 15,
    mana: 5,
    cost: 300
  }
});
