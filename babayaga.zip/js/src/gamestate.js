define({
   active : false,
  paused : false,
  endcondition : 0
})
