function tilemap(width,height){
  this.width = width;
  this.height = height;
}

function sprite(){
  
}
